from docx import Document
from docx.shared import Pt

DEFAULT_FONT_SIZE_PT = 12
DELTA_PT = 0.5

def message_to_binary(message):
    return ''.join(format(ord(char), '08b') for char in message)

def encode_docx(input_docx, output_docx, message):
    doc = Document(input_docx)
    binary_msg = message_to_binary(message)
    total_bits = len(binary_msg)
    embedded_bits = 0

    print(f"[INFO] Total bits to embed: {total_bits}")

    for para in doc.paragraphs:
        for run in para.runs:
            new_text = ""
            for char in run.text:
                if embedded_bits >= total_bits:
                    new_text += char
                    continue

                if char in '.,;:!?()[]{}"\'‘’“”…—–':
                    bit = binary_msg[embedded_bits]
                    new_run = para.add_run(char)

                    original_size = run.font.size.pt if run.font.size else DEFAULT_FONT_SIZE_PT

                    if bit == '1':
                        new_run.font.size = Pt(original_size + DELTA_PT)
                    else:
                        new_run.font.size = Pt(original_size - DELTA_PT)

                    embedded_bits += 1
                else:
                    new_run = para.add_run(char)
                    new_run.font.size = run.font.size

            run.text = ''

        if embedded_bits >= total_bits:
            break

    doc.save(output_docx)
    print("[+] Message embedded successfully!")
    print(f"[INFO] Output file: {output_docx}")
    print(f"[INFO] Bits embedded: {embedded_bits}")

input_doc = "input.docx"
output_doc = "output.docx"
student_char = input("Enter the last digit of your student ID: ").strip()[0]

encode_docx(input_doc, output_doc, student_char)
