from docx import Document

def count_punctuation(doc):
    punctuation = '.,;:!?()[]{}"\'‘’“”…—–'
    count = 0
    for para in doc.paragraphs:
        for run in para.runs:
            for char in run.text:
                if char in punctuation:
                    count += 1
    return count

def check_punctuation_capacity(input_docx, message):
    doc = Document(input_docx)
    punctuation_count = count_punctuation(doc)
    binary_length = len(format(ord(message), '08b'))

    print(f"[INFO] Punctuation available: {punctuation_count}")
    print(f"[INFO] Bits required to hide: {binary_length}")

    if punctuation_count >= binary_length:
        print("[+] Good: Enough punctuation marks to hide the message.")
    else:
        print(f"[ERROR] Not enough punctuation marks. You need at least {binary_length} punctuation marks.")

input_doc = "input.docx"
student_char = input("Enter the last digit of your student ID: ").strip()[0]
check_punctuation_capacity(input_doc, student_char)
