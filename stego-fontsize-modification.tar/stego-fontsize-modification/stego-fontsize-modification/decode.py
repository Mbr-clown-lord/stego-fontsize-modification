from docx import Document

DEFAULT_FONT_SIZE_PT = 12

def binary_to_message(binary_str):
    chars = [binary_str[i:i+8] for i in range(0, len(binary_str), 8)]
    return ''.join(chr(int(b, 2)) for b in chars)

def decode_docx_from_punctuation(input_docx, expected_length):
    doc = Document(input_docx)
    binary_str = ""
    collected_bits = 0

    for para in doc.paragraphs:
        for run in para.runs:
            for char in run.text:
                if char in '.,;:!?()[]{}"\'‘’“”…—–':
                    size = run.font.size
                    if size is not None:
                        size_val = size.pt
                        deviation = round(size_val - DEFAULT_FONT_SIZE_PT, 2)

                        if abs(deviation) < 0.1:
                            continue
                        elif deviation > 0:
                            bit = '1'
                        else:
                            bit = '0'

                        binary_str += bit
                        collected_bits += 1

                        if collected_bits >= expected_length * 8:
                            break
            if collected_bits >= expected_length * 8:
                break
        if collected_bits >= expected_length * 8:
            break

    print(f"[DEBUG] Extracted binary string: {binary_str}")
    message = binary_to_message(binary_str)
    print("[+] Decoded message:", message)

input_doc = "output.docx"
expected_length = 1

decode_docx_from_punctuation(input_doc, expected_length)
